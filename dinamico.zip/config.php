<?php
// Configuración del catálogo
return [
    'titulo'     => 'Mi catálogo',
    // URL (o ruta local) de TU lista M3U/M3U8. Usa solo contenido que tengas derecho a reproducir.
    'playlist'   => '',
    'cache_min'  => 30,   // minutos que se guarda la lista en disco
    'por_pagina' => 48,   // títulos por página
];
