<?php
$cfg = require __DIR__ . '/config.php';

function cargar_lista(array $cfg): string {
    $src = trim($cfg['playlist']);
    if ($src === '') return '';
    if (!preg_match('~^https?://~i', $src)) return (string)@file_get_contents($src);
    $cache = sys_get_temp_dir() . '/m3u_' . md5($src) . '.cache';
    if (is_file($cache) && time() - filemtime($cache) < $cfg['cache_min'] * 60) return file_get_contents($cache);
    $ch = curl_init($src);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => 20, CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS]);
    $txt = curl_exec($ch);
    curl_close($ch);
    if ($txt) { file_put_contents($cache, $txt); return $txt; }
    return is_file($cache) ? file_get_contents($cache) : '';
}

function parsear(string $txt): array {
    $items = []; $meta = null;
    foreach (preg_split('/\R/u', ltrim($txt, "\xEF\xBB\xBF")) as $l) {
        $l = trim($l);
        if ($l === '' || $l === '#EXTM3U') continue;
        if (strpos($l, '#EXTINF') === 0) {
            $meta = ['nombre' => trim(substr(strrchr($l, ','), 1)), 'grupo' => 'General', 'logo' => ''];
            if (preg_match('/group-title="([^"]*)"/i', $l, $m) && $m[1] !== '') $meta['grupo'] = $m[1];
            if (preg_match('/tvg-logo="([^"]*)"/i', $l, $m)) $meta['logo'] = $m[1];
        } elseif ($l[0] !== '#' && $meta) {
            if (preg_match('~^https?://~i', $l)) { $meta['url'] = $l; $items[] = $meta; }
            $meta = null;
        }
    }
    return $items;
}

$e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
$items = parsear(cargar_lista($cfg));
$grupos = [];
foreach ($items as $i) $grupos[$i['grupo']] = ($grupos[$i['grupo']] ?? 0) + 1;
ksort($grupos, SORT_NATURAL | SORT_FLAG_CASE);

$grupo = $_GET['grupo'] ?? '';
$q = trim($_GET['q'] ?? '');
$lista = array_values(array_filter($items, function ($i) use ($grupo, $q) {
    if ($grupo !== '' && $i['grupo'] !== $grupo) return false;
    return $q === '' || stripos($i['nombre'], $q) !== false;
}));
$total = count($lista);
$pp = max(1, (int)$cfg['por_pagina']);
$paginas = max(1, (int)ceil($total / $pp));
$pag = min(max(1, (int)($_GET['p'] ?? 1)), $paginas);
$pagina = array_slice($lista, ($pag - 1) * $pp, $pp);
$url = fn(array $p) => '?' . http_build_query(array_filter(array_merge(['grupo' => $grupo, 'q' => $q, 'p' => $pag], $p), fn($v) => $v !== '' && $v !== 1));
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= $e($cfg['titulo']) ?></title>
<style>
:root{--bg:#0f1720;--panel:#18222e;--line:#263444;--txt:#e6edf3;--mute:#8b9bab;--acc:#3ddbb0}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--txt);font:16px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}
a{color:inherit;text-decoration:none}
header{display:flex;gap:1rem;align-items:center;flex-wrap:wrap;padding:1rem 1.25rem;border-bottom:1px solid var(--line);position:sticky;top:0;background:var(--bg);z-index:5}
h1{margin:0;font-size:1.35rem;letter-spacing:-.01em}
form{margin-left:auto;display:flex;gap:.5rem}
input[type=search]{background:var(--panel);border:1px solid var(--line);color:var(--txt);padding:.5rem .8rem;border-radius:8px;min-width:200px}
button{background:var(--acc);color:#04201a;border:0;border-radius:8px;padding:.5rem 1rem;font-weight:600;cursor:pointer}
nav.g{display:flex;gap:.5rem;overflow-x:auto;padding:.75rem 1.25rem;border-bottom:1px solid var(--line)}
nav.g a{white-space:nowrap;padding:.3rem .8rem;border:1px solid var(--line);border-radius:99px;color:var(--mute);font-size:.9rem}
nav.g a.on,nav.g a:hover{color:var(--txt);border-color:var(--acc)}
main{padding:1.25rem}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:1rem}
.card{background:var(--panel);border:0;padding:0;text-align:left;color:inherit;border-radius:10px;overflow:hidden;cursor:pointer;font:inherit}
.card:focus-visible,button:focus-visible,a:focus-visible,input:focus-visible{outline:2px solid var(--acc);outline-offset:2px}
.poster{aspect-ratio:2/3;background:#223142;display:grid;place-items:center;font-size:2.5rem;font-weight:700;color:var(--mute)}
.poster img{width:100%;height:100%;object-fit:cover}
.card span.t{display:block;padding:.5rem .6rem;font-size:.85rem;line-height:1.3}
.vacio{padding:3rem 1rem;text-align:center;color:var(--mute)}
.pag{display:flex;gap:1rem;justify-content:center;margin:1.5rem 0;color:var(--mute)}
.pag a{color:var(--acc)}
dialog{border:0;padding:0;background:#000;width:min(960px,96vw);border-radius:12px;overflow:hidden}
dialog::backdrop{background:rgba(0,0,0,.75)}
dialog .bar{display:flex;justify-content:space-between;align-items:center;padding:.6rem 1rem;background:var(--panel);color:var(--txt)}
dialog video{width:100%;max-height:75vh;display:block;background:#000}
#err{padding:.5rem 1rem;color:#ffb4a8;font-size:.9rem;display:none;background:var(--panel)}
</style>
</head>
<body>
<header>
  <h1><a href="?"><?= $e($cfg['titulo']) ?></a></h1>
  <form method="get">
    <?php if ($grupo !== ''): ?><input type="hidden" name="grupo" value="<?= $e($grupo) ?>"><?php endif; ?>
    <input type="search" name="q" value="<?= $e($q) ?>" placeholder="Buscar título" aria-label="Buscar título">
    <button>Buscar</button>
  </form>
</header>
<?php if ($grupos): ?>
<nav class="g" aria-label="Categorías">
  <a href="?" class="<?= $grupo === '' ? 'on' : '' ?>">Todos (<?= count($items) ?>)</a>
  <?php foreach ($grupos as $g => $n): ?>
    <a href="?<?= $e(http_build_query(['grupo' => $g])) ?>" class="<?= $g === $grupo ? 'on' : '' ?>"><?= $e($g) ?> (<?= $n ?>)</a>
  <?php endforeach; ?>
</nav>
<?php endif; ?>
<main>
<?php if (!$items): ?>
  <p class="vacio">No hay lista cargada. Define la URL de tu M3U en <code>config.php</code> (clave <code>playlist</code>).</p>
<?php elseif (!$pagina): ?>
  <p class="vacio">Sin resultados<?= $q !== '' ? ' para “' . $e($q) . '”' : '' ?>.</p>
<?php else: ?>
  <div class="grid">
  <?php foreach ($pagina as $i): ?>
    <button class="card" data-url="<?= $e($i['url']) ?>" data-t="<?= $e($i['nombre']) ?>">
      <div class="poster"><?php if ($i['logo']): ?><img src="<?= $e($i['logo']) ?>" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.remove()"><?php endif; ?><?= $e(mb_strtoupper(mb_substr($i['nombre'], 0, 1))) ?></div>
      <span class="t"><?= $e($i['nombre']) ?></span>
    </button>
  <?php endforeach; ?>
  </div>
  <?php if ($paginas > 1): ?>
  <div class="pag">
    <?php if ($pag > 1): ?><a href="<?= $e($url(['p' => $pag - 1])) ?>">Anterior</a><?php endif; ?>
    <span>Página <?= $pag ?> de <?= $paginas ?></span>
    <?php if ($pag < $paginas): ?><a href="<?= $e($url(['p' => $pag + 1])) ?>">Siguiente</a><?php endif; ?>
  </div>
  <?php endif; ?>
<?php endif; ?>
</main>

<dialog id="player">
  <div class="bar"><strong id="pt"></strong><button id="cerrar" type="button">Cerrar</button></div>
  <video id="v" controls playsinline></video>
  <div id="err"></div>
</dialog>

<script src="https://cdnjs.cloudflare.com/ajax/libs/hls.js/1.5.13/hls.min.js"></script>
<script>
const dlg = document.getElementById('player'), v = document.getElementById('v'),
      err = document.getElementById('err'), pt = document.getElementById('pt');
let hls;
function parar(){ if (hls) { hls.destroy(); hls = null; } v.pause(); v.removeAttribute('src'); v.load(); }
function reproducir(url, titulo){
  parar(); err.style.display = 'none'; pt.textContent = titulo; dlg.showModal();
  if (/\.m3u8(\?|$)/i.test(url) && window.Hls && Hls.isSupported()) {
    hls = new Hls(); hls.loadSource(url); hls.attachMedia(v);
    hls.on(Hls.Events.ERROR, (_, d) => { if (d.fatal) fallo(); });
  } else { v.src = url; }
  v.play().catch(() => {});
}
function fallo(){ err.textContent = 'No se pudo reproducir este título. Revisa que el enlace siga activo y use HTTPS si tu sitio usa HTTPS.'; err.style.display = 'block'; }
v.addEventListener('error', fallo);
document.querySelectorAll('.card').forEach(c => c.addEventListener('click', () => reproducir(c.dataset.url, c.dataset.t)));
document.getElementById('cerrar').addEventListener('click', () => dlg.close());
dlg.addEventListener('close', parar);
dlg.addEventListener('click', e => { if (e.target === dlg) dlg.close(); });
</script>
</body>
</html>
